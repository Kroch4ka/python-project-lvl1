

def welcome_user():
    name = input('May I have your name? ')
    print("Hello, {}!".format(name))


